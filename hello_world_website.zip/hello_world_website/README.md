# Hello World Website

A simple "Hello World" website created for the GitHub repository nbliss536/GIT.

## Features

- Basic HTML structure
- Responsive design
- Clean, modern styling

## Usage

Simply open the `index.html` file in any web browser to view the website.
