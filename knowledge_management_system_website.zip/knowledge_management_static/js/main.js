// Main JavaScript for Knowledge Management System

document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    if (tabs.length > 0) {
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                // Remove active class from all tabs and content
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab and corresponding content
                this.classList.add('active');
                const contentId = `${this.dataset.tab}-content`;
                const content = document.getElementById(contentId);
                if (content) {
                    content.classList.add('active');
                }
            });
        });
    }
    
    // Initialize charts if they exist
    if (typeof Chart !== 'undefined') {
        // Term Frequency Chart
        const termFrequencyCtx = document.getElementById('termFrequencyChart');
        if (termFrequencyCtx) {
            new Chart(termFrequencyCtx, {
                type: 'bar',
                data: {
                    labels: ['Acoustics', 'Harmonics', 'Resonance', 'Frequency', 'Timbre', 'Synthesis', 'Composition', 'Performance', 'Perception', 'Psychoacoustics'],
                    datasets: [{
                        label: 'Term Frequency',
                        data: [65, 59, 80, 81, 56, 55, 40, 35, 30, 25],
                        backgroundColor: 'rgba(52, 152, 219, 0.7)',
                        borderColor: 'rgba(52, 152, 219, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
        
        // Domain Connections Chart
        const domainConnectionsCtx = document.getElementById('domainConnectionsChart');
        if (domainConnectionsCtx) {
            new Chart(domainConnectionsCtx, {
                type: 'radar',
                data: {
                    labels: ['Acoustics', 'Music Theory', 'Signal Processing', 'Composition', 'Performance', 'Psychoacoustics'],
                    datasets: [{
                        label: 'Connection Strength',
                        data: [0.8, 0.6, 0.9, 0.7, 0.5, 0.85],
                        backgroundColor: 'rgba(46, 204, 113, 0.2)',
                        borderColor: 'rgba(46, 204, 113, 1)',
                        pointBackgroundColor: 'rgba(46, 204, 113, 1)',
                        pointBorderColor: '#fff',
                        pointHoverBackgroundColor: '#fff',
                        pointHoverBorderColor: 'rgba(46, 204, 113, 1)'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
        
        // Confidence Distribution Chart
        const confidenceCtx = document.getElementById('confidenceChart');
        if (confidenceCtx) {
            new Chart(confidenceCtx, {
                type: 'pie',
                data: {
                    labels: ['High Confidence', 'Medium Confidence', 'Low Confidence'],
                    datasets: [{
                        data: [25, 20, 13],
                        backgroundColor: [
                            'rgba(46, 204, 113, 0.7)',
                            'rgba(243, 156, 18, 0.7)',
                            'rgba(231, 76, 60, 0.7)'
                        ],
                        borderColor: [
                            'rgba(46, 204, 113, 1)',
                            'rgba(243, 156, 18, 1)',
                            'rgba(231, 76, 60, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
        
        // Activity Chart
        const activityChartCtx = document.getElementById('activityChart');
        if (activityChartCtx) {
            new Chart(activityChartCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
                    datasets: [
                        {
                            label: 'Commits',
                            data: [12, 19, 15, 23, 28],
                            borderColor: '#3498db',
                            backgroundColor: 'rgba(52, 152, 219, 0.1)',
                            tension: 0.4
                        },
                        {
                            label: 'Issues',
                            data: [5, 8, 12, 7, 10],
                            borderColor: '#e74c3c',
                            backgroundColor: 'rgba(231, 76, 60, 0.1)',
                            tension: 0.4
                        },
                        {
                            label: 'Pull Requests',
                            data: [3, 5, 4, 7, 9],
                            borderColor: '#2ecc71',
                            backgroundColor: 'rgba(46, 204, 113, 0.1)',
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Repository Activity Over Time'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }
    
    // Direction type filter functionality
    const directionFilter = document.getElementById('direction-filter');
    if (directionFilter) {
        directionFilter.addEventListener('change', function() {
            const selectedType = this.value;
            const directions = document.querySelectorAll('.research-direction');
            
            directions.forEach(direction => {
                if (selectedType === 'all' || direction.dataset.type === selectedType) {
                    direction.style.display = 'block';
                } else {
                    direction.style.display = 'none';
                }
            });
        });
    }
});
